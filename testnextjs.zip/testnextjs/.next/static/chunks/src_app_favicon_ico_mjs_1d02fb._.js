(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_favicon_ico_mjs_1d02fb._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_favicon_ico_mjs_1d02fb._.js",
  "chunks": [
    "static/chunks/_98a1d9._.js"
  ],
  "source": "dynamic"
});
