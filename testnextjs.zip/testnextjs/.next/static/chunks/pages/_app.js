__turbopack_load_page_chunks__("/_app", [
  "static/chunks/[root of the server]__fcbd0e._.js",
  "static/chunks/545c3_react-dom_1c85ba._.js",
  "static/chunks/node_modules__pnpm_f84813._.js",
  "static/chunks/[root of the server]__f265a1._.js",
  "static/chunks/pages__app_5771e1._.js",
  "static/chunks/pages__app_8d7c41._.js"
])
