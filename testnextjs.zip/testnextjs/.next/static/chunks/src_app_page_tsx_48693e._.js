(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_page_tsx_48693e._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_page_tsx_48693e._.js",
  "chunks": [
    "static/chunks/3aadb_next_dist_cbb15d._.js",
    "static/chunks/src_app_page_tsx_8b213b._.js",
    "static/chunks/src_app_page_module_d12eb7.css"
  ],
  "source": "dynamic"
});
